//
//  Post.swift
//  Picnix
//
//  Created by Student on 10/30/23.
//

import Foundation

struct Post: Codable, Identifiable {
    let id: Int
    let image: String
    let flow: String
    let amount: Int
    let createdAt: String
    let businessName: String
    let businessId: Int
    let username: String
    let userId: Int
    let isPrivate: Bool
    let caption: String?
    
    enum CodingKeys: String, CodingKey {
            case id
            case image
            case flow
            case amount
            case createdAt
            case businessName
            case businessId
            case username
            case userId
            case isPrivate = "private"
            case caption
    }
}
