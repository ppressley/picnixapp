//
//  PicnixApp.swift
//  Picnix
//
//  Created by Student on 10/26/23.
//

import SwiftUI

@main
struct PicnixApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
