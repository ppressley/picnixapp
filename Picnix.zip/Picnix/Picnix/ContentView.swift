//
//  ContentView.swift
//  Picnix
//
//  Created by Student on 10/26/23.
//

import SwiftUI

struct ContentView: View {
    @State private var posts: [Post] = []
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.yellow, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack {
                Text("**PicNix**")
                    .font(.system(size: 50))
                    .foregroundColor(.black)
                    .shadow(color: .green, radius: 12)
                Spacer()
                Spacer()
                    .frame(width: 370, height: 650)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                        
                    )
                Spacer()
            }
            List(posts) { post in
                HStack {
                    VStack(alignment: .leading) {
                        Text(post.username)
                            .bold()
                            .lineLimit(1)
                            .font(.title3)
                        Text(post.createdAt)
                                // how to alter this?
                                .lineLimit(1)
                                .font(.footnote)
                        
                        Text("Post #: \(post.id)")
                    }
                }
                .listRowBackground(LinearGradient(
                    colors: [.yellow, .green],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
            }
            .frame(width: 370, height: 550)
            .scrollContentBackground(.hidden)
            .foregroundColor(.black)
            .onAppear {
                pullPosts()
            }
            
        }
    }
    
    func pullPosts() {
        guard let url = URL(string: "https://www.jalirani.com/files/picnix.json") else { return }
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else { return }
            if let data = data {
                do {
                    //Parse JSON
                    let decodedData = try JSONDecoder().decode([Post].self, from: data)
                    self.posts = decodedData
                } catch {
                    print("Error decoding JSON: \(error.localizedDescription)")
                }
            } else if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
            }
        }.resume()
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
