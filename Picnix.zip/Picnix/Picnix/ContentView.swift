//
//  ContentView.swift
//  Picnix
//
//  Created by Student on 10/26/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.yellow, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack {
                Text("**PicNix**")
                    .font(.system(size: 50))
                    .foregroundColor(.black)
                    .shadow(color: .green, radius: 12)
                Spacer()
                Spacer()
                    .frame(width: 370, height: 650)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                        
                    )
            }
            Text("Feed")
                .foregroundColor(.white)
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
