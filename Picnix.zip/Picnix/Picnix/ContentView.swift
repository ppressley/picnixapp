//
//  ContentView.swift
//  Picnix
//
//  Created by Student on 10/26/23.
//

import SwiftUI

struct SheetView: View {
    @Binding var posts: [Post]
    @Environment(\.dismiss) var dismiss

    var body: some View {
        LinearGradient(
            colors: [.yellow, .green],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
        
        List(posts) { post in
            HStack {
                Text(post.username)
            }
        }
        Button("❌") {
            dismiss()
        }
        .font(.title)

    }
}

struct ContentView: View {
    @State private var posts: [Post] = []
    @State private var showingSheet = false
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.yellow, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack {
                Text("**PicNix**")
                    .font(.system(size: 50))
                    .foregroundColor(.black)
                    .shadow(color: .green, radius: 12)
            
                Spacer()
                Spacer()
                    .frame(width: 370, height: 650)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                        
                    )
                Spacer()
            }
            List(posts) { post in
                HStack {
                    VStack(alignment: .leading) {
                        
                        // USERNAME
                        Button(post.username) {
                                    showingSheet.toggle()
                                }
                        .sheet(isPresented: $showingSheet) {
                            SheetView(posts: self.$posts)
                        }
                                .bold()
                                .lineLimit(1)
                                .font(.title3)
                        
                        // IMAGE
                        AsyncImage(url: URL(string: post.image)) { image in
                            image.resizable()
                        } placeholder: {
                            ProgressView()
                        }
                            .frame(width: 300, height: 200, alignment: .center)
                            .border(.pink)
                        
                        // BUSINESS & LIKES
                        Text(post.businessName)
                        Text(String(post.amount)+"❤️")
                            .frame(width: 50, height: 10, alignment: .trailing)
                            
                        // CAPTION
                        Divider()
                        if let unwrapped = post.caption {
                            Text(unwrapped)
                                .font(.system(size: 12))
                        } else {
                            Text("No Caption for this post")
                                .font(.system(size: 12))
                        }
                        
                        // TIMESTAMP
                        Text(post.createdAt)
                                .lineLimit(1)
                                .font(.footnote)
                    }
                }
                .listRowBackground(LinearGradient(
                    colors: [.yellow, .green],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
            }
            .frame(width: 370, height: 550)
            .scrollContentBackground(.hidden)
            .foregroundColor(.black)
            .onAppear {
                pullPosts()
            }
            
        }
    }
    
    func pullPosts() {
        guard let url = URL(string: "https://www.jalirani.com/files/picnix.json") else { return }
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else { return }
            if let data = data {
                do {
                    //Parse JSON
                    let decodedData = try JSONDecoder().decode([Post].self, from: data)
                    self.posts = decodedData
                } catch {
                    print("Error decoding JSON: \(error.localizedDescription)")
                }
            } else if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
            }
        }.resume()
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
