//
//  ContentView.swift
//  Picnix
//
//  Created by Student on 10/26/23.
//

import SwiftUI
import Foundation

extension Date {
    func timeAgoDisplay() -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .full
        return formatter.localizedString(for: self, relativeTo: Date())
    }
}

struct SheetView: View {
    @Binding var selectedPost: Post?
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.yellow, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack {
                HStack {
                    Spacer()
                    Button("❌") {
                        dismiss()
                    }
                    .font(.title)
                    .padding()
                }
                if let post = selectedPost {
                    Text(post.username)
                        .font(.system(size: 30))
                        .foregroundColor(.black)
                        .shadow(color: .green, radius: 12)
                    AsyncImage(url: URL(string: post.image)) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                        .frame(width: 350, height: 300, alignment: .center)
                        .border(.pink)
                    
                    // BUSINESS & LIKES
                    Text(post.businessName)
                    Text(String(post.amount)+"❤️")
                        .frame(width: 50, height: 10, alignment: .trailing)
                    
                    // CAPTION
                    Divider()
                    if let unwrapped = post.caption {
                        Text(unwrapped)
                            .font(.system(size: 12))
                    } else {
                        Text("No Caption for this post")
                            .font(.system(size: 12))
                    }
                    

                    // TIMESTAMP
                    var formattedDate: String {
                        let fixedFormatter = DateFormatter()
                        fixedFormatter.locale = Locale(identifier: "en_US_POSIX")
                        fixedFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
                        fixedFormatter.timeZone = TimeZone(abbreviation: "GMT")
                        
                        if let date = fixedFormatter.date(from: post.createdAt) {
                            let fullDate = fixedFormatter.string(from: date)
                            let first10Characters = String(fullDate.prefix(10))
                            return first10Characters
                        } else {
                            return "Invalid Date"
                        }
                    }


                    Text(formattedDate)




                    
   
                } else {
                    
                    Text("No post selected")
                }
                Spacer()
                
            }
        }
    }
}

struct ContentView: View {
    @ObservedObject var postViewModel = PostViewModel()
    @State private var selectedPost: Post?
    @State private var showingSheet = false
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.yellow, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack {
                Text("**PicNix**")
                    .font(.system(size: 50))
                    .foregroundColor(.black)
                    .shadow(color: .green, radius: 12)
            
                Spacer()
                Spacer()
                    .frame(width: 370, height: 650)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                        
                    )
                Spacer()
            }
            if postViewModel.isLoading {
                VStack {
                    Text("Fetching new posts")
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                        .shadow(color: .green, radius: 12)
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: Color.yellow))
                }
            } else {
                List {
                    ForEach(postViewModel.posts, id: \.id) { post in
                        HStack {
                            VStack(alignment: .leading) {
                                
                                // Gets rid of corrupt posts
                                if post.flow != "CORRUPT" {
                                    Button(post.username) {
                                        if (!post.isPrivate) {
                                            selectedPost = post
                                            showingSheet.toggle()
                                        }
                                    }
                                        .bold()
                                        .lineLimit(1)
                                        .font(.title3)

                                    AsyncImage(url: URL(string: post.image)) { image in image.resizable()} placeholder: {
                                        ProgressView()
                                    }
                                    .frame(width: 300, height: 200, alignment: .center)
                                    .border(.pink)

                                    Text(post.businessName)
                                    Text("\(post.amount)❤️")
                                        .frame(width: 50, height: 10, alignment: .trailing)
                                    
                                    let timeAgoString = calculateTimeAgo(from: post.createdAt)
                                    Text(timeAgoString)
                                        .font(.system(size: 12))

                                }
                        }
                    }
                    .listRowBackground(
                        LinearGradient(
                            colors: [.yellow, .green],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                }
            }
                .frame(width: 370, height: 550)
                .scrollContentBackground(.hidden)
                .foregroundColor(.black)
                .onAppear {
                    postViewModel.fetchPosts()
                }
                .sheet(isPresented: $showingSheet) {
                    SheetView(selectedPost: $selectedPost)
                }
            }
        }
    }
    
    func calculateTimeAgo(from createdAt: String) -> String {
        let fixedFormatter = DateFormatter()
        fixedFormatter.locale = Locale(identifier: "en_US_POSIX")
        fixedFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        fixedFormatter.timeZone = TimeZone(abbreviation: "GMT")
        
        if let date = fixedFormatter.date(from: createdAt) {
            let calendar = Calendar.current
            let now = Date()
            let components = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: date, to: now)
            
            if let year = components.year, year > 0 {
                return year == 1 ? "1 year ago" : "\(year) years ago"
            } else if let month = components.month, month > 0 {
                return month == 1 ? "1 month ago" : "\(month) months ago"
            } else if let day = components.day, day > 0 {
                return day == 1 ? "1 day ago" : "\(day) days ago"
            } else if let hour = components.hour, hour > 0 {
                return hour == 1 ? "1 hour ago" : "\(hour) hours ago"
            } else if let minute = components.minute, minute > 0 {
                return minute == 1 ? "1 minute ago" : "\(minute) minutes ago"
            } else {
                return "Just now"
            }
        } else {
            return "Invalid Date"
        }
    }
}

class PostViewModel: ObservableObject {
    @Published var posts: [Post] = []
    @Published var isLoading = false //SET THIS TO TRUE for loading view. App wouldn't update despite the value of isLoading changing.

    func fetchPosts() {
        guard let url = URL(string: "https://www.jalirani.com/files/picnix.json") else { return }

        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else { return }
            if let data = data {
                do {
                    let decodedData = try JSONDecoder().decode([Post].self, from: data)
                    self.posts = decodedData
                    self.isLoading = false
                } catch {
                    print("Error decoding JSON: \(error.localizedDescription)")
                }
            } else if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
            }
        }.resume()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
